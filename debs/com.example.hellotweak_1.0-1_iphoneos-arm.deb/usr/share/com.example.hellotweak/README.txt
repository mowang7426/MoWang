Hello from your jailbreak repo!

把真正的插件 .deb 放进 debs/ 目录，然后运行 ./build.sh 重建索引。
