# SBLiquidGlass Source Notice

Source supplied by the user as `ceshi-main` (SBLiquidGlass V1.1.0 Alpha 2).
The upstream README states that this project derives from the GPL-licensed
LiquidAss source architecture. The supplied GPL version 3 text is retained
in `LICENSE`. No separately distributed Liquidify binary is included.

Imported files:

- `LGSymbolResolver.h` and `.mm`: copied from SBLiquidGlassBackboardd.
- `Shader.inc`: extracted Metal source from SBLiquidGlassBackboardd/Tweak.mm.

ChatAssist modifications, September 20, 2026:

- Added a bounded nine-tap backdrop sampling helper and a blur-radius uniform
  to distinguish clear and soft surfaces.
- The new `GlassRenderer/Renderer.mm` adapts the reference's private filter
  registration and rendering technique to ChatAssist-only filter names.
  It omits all desktop, icon, wallpaper, lock-screen and other host hooks.
- No screenshot files or screen-content network requests are used by this renderer.

The renderer and shader adaptations are provided under GPL-3.0.
The release source archive contains their corresponding source and build files.
